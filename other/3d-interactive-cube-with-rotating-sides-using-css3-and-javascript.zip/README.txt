A Pen created at CodePen.io. You can find this one at https://codepen.io/jordizle/pen/haIdo.

 An experiment using a combination of CSS3 and JavaScript to animate a cube based on mouse and touch events. Each individual side of the cube's content is automatically rotated as the user moves the cube to keep the content viewable from any angle.